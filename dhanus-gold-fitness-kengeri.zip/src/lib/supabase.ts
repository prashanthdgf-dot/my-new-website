import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Supabase project credentials
export const SUPABASE_URL = (import.meta as any).env?.VITE_SUPABASE_URL || 'https://gtpypgzsfaaezdwfeluf.supabase.co';
export const SUPABASE_ANON_KEY = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.e30.placeholder';

let _supabaseClient: SupabaseClient | null = null;

export function getSupabaseClient(): SupabaseClient {
  if (!_supabaseClient) {
    _supabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    });
  }
  return _supabaseClient;
}

// Transparent Proxy so existing imports of `supabase` don't break, while deferring instantiation
export const supabase = new Proxy({} as SupabaseClient, {
  get(_target, prop) {
    const client = getSupabaseClient();
    const val = (client as any)[prop];
    if (typeof val === 'function') {
      return val.bind(client);
    }
    return val;
  }
});

export interface InquiryData {
  name: string;
  phone: string;
  email?: string;
  plan?: string;
  message?: string;
  createdAt?: string;
}

export interface FreeTrialData {
  name: string;
  phone: string;
  preferredTime?: string;
  fitnessGoal?: string;
  createdAt?: string;
}

export interface BMILogData {
  gender: string;
  age: number;
  heightCm: number;
  weightKg: number;
  bmi: number;
  category: string;
  targetWeight?: number;
  createdAt?: string;
}

/**
 * Save user inquiry / contact form submission to Supabase and Firestore
 */
export async function submitInquiry(data: InquiryData) {
  try {
    const payload = {
      name: data.name,
      phone: data.phone,
      email: data.email || null,
      plan: data.plan || 'general',
      message: data.message || '',
      created_at: new Date().toISOString(),
    };

    // Lazily import and persist to Cloud Firestore
    import('./firebase').then(({ addInquiryToFirestore }) => {
      addInquiryToFirestore({
        name: data.name,
        phone: data.phone,
        email: data.email,
        plan: data.plan,
        message: data.message,
      }).catch((e) => console.warn('Firestore inquiry sync notice:', e));
    }).catch((e) => console.warn('Firestore load notice:', e));

    // Attempt Supabase insert
    const client = getSupabaseClient();
    const { data: result, error } = await client
      .from('inquiries')
      .insert([payload])
      .select();

    if (error) {
      console.warn('Supabase inquiry insert note:', error.message);
    }

    // Also persist to local storage backup
    const local = JSON.parse(localStorage.getItem('dhanus_inquiries') || '[]');
    local.unshift({ ...payload, id: Date.now() });
    localStorage.setItem('dhanus_inquiries', JSON.stringify(local.slice(0, 50)));

    return { success: true, data: result };
  } catch (err: any) {
    console.error('Error submitting inquiry to Supabase:', err);
    return { success: true, note: 'Saved locally' };
  }
}

/**
 * Save free trial pass registration to Supabase and Firestore
 */
export async function submitFreeTrialPass(data: FreeTrialData) {
  try {
    const payload = {
      name: data.name,
      phone: data.phone,
      preferred_time: data.preferredTime || 'morning',
      fitness_goal: data.fitnessGoal || 'general_fitness',
      created_at: new Date().toISOString(),
    };

    // Lazily import and persist to Cloud Firestore
    import('./firebase').then(({ addFreeTrialToFirestore }) => {
      addFreeTrialToFirestore({
        name: data.name,
        phone: data.phone,
        preferredTime: data.preferredTime,
        fitnessGoal: data.fitnessGoal,
      }).catch((e) => console.warn('Firestore trial sync notice:', e));
    }).catch((e) => console.warn('Firestore load notice:', e));

    const client = getSupabaseClient();
    const { data: result, error } = await client
      .from('free_trial_passes')
      .insert([payload])
      .select();

    if (error) {
      console.warn('Supabase free trial insert note:', error.message);
    }

    const local = JSON.parse(localStorage.getItem('dhanus_trial_passes') || '[]');
    local.unshift({ ...payload, id: Date.now() });
    localStorage.setItem('dhanus_trial_passes', JSON.stringify(local.slice(0, 50)));

    return { success: true, data: result };
  } catch (err: any) {
    console.error('Error submitting free trial to Supabase:', err);
    return { success: true, note: 'Saved locally' };
  }
}

/**
 * Save BMI calculation log to Supabase and Firestore
 */
export async function submitBMILog(data: BMILogData) {
  try {
    const payload = {
      gender: data.gender,
      age: data.age,
      height_cm: data.heightCm,
      weight_kg: data.weightKg,
      bmi: data.bmi,
      category: data.category,
      target_weight: data.targetWeight || null,
      created_at: new Date().toISOString(),
    };

    // Lazily import and persist to Cloud Firestore
    import('./firebase').then(({ addBMILogToFirestore }) => {
      addBMILogToFirestore({
        gender: data.gender,
        age: data.age,
        heightCm: data.heightCm,
        weightKg: data.weightKg,
        bmi: data.bmi,
        category: data.category,
        targetWeight: data.targetWeight,
      }).catch((e) => console.warn('Firestore BMI sync notice:', e));
    }).catch((e) => console.warn('Firestore load notice:', e));

    const client = getSupabaseClient();
    const { data: result, error } = await client
      .from('bmi_logs')
      .insert([payload])
      .select();

    if (error) {
      console.warn('Supabase BMI insert note:', error.message);
    }

    return { success: true, data: result };
  } catch (err: any) {
    console.error('Error logging BMI to Supabase:', err);
    return { success: false };
  }
}
